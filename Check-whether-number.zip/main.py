#To check if a number is positive, negative or Zero 

number = int(input("Enter a number: "))

if number > 0 :
  print("The number is positive!")
elif number < 0:
  print("The number is negative!")
else:
  print("The number is Zero!")

